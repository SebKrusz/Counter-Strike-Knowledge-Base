
import "./HomePage.scss"

const HomePage = () => {
    return (
        <>

        </>
    )
}

export default HomePage;