// TestWebsite.js
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import axios from "axios";

function TestWebsite() {
	const { id } = useParams();
	const [websiteData, setWebsiteData] = useState(null);

	useEffect(() => {
		const fetchWebsiteData = async () => {
			try {
				const response = await axios.get(
					`http://localhost:8080/website/${id}`
				);
				setWebsiteData(response.data);
			} catch (err) {
				console.error(err.message);
			}
		};

		fetchWebsiteData();
	}, [id]);

	if (!websiteData) {
		return <div>Loading...</div>;
	}

	return (
		<main className="url-check">
			<div className="url-check__container">
				<div className="url-check__container-titlebox">
					<h1 className="url-check__container-title">
						Here is information for: {websiteData.website_domain}
					</h1>
					<div className="url-check__container-hero-form">
						<Link to="/websites">
							<button className="url-check__container-FAQ-button">
								Back to the previous page
							</button>
						</Link>
					</div>
				</div>
				<div className="url-check__container-table">
					<div className="url-check__container-headers">
						<h2 className="url-check__FAQ-card-header">
							Down below you can find the most common questions
							and answers regarding {websiteData.website_domain}.
						</h2>
						<p className="url-check__FAQ-card-question">
							Question one
						</p>
						<p className="url-check__FAQ-card-answer">
							Answer 1 Paragraph 1
						</p>
						<p className="url-check__FAQ-card-answer">
							Answer 1 Paragraph 2
						</p>
						<p className="url-check__FAQ-card-question">
							Question 2
						</p>
						<p className="url-check__FAQ-card-answer">Answer 2</p>
						<p className="url-check__FAQ-card-question">
							Question 3
						</p>
						<p className="url-check__FAQ-card-answer"> Answer 3</p>
					</div>
				</div>
			</div>
		</main>
	);
}

export default TestWebsite;
