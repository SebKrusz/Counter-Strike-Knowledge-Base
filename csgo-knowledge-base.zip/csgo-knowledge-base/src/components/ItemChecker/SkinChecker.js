import "./SkinChecker.scss";
import axios from "axios";
import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";

function SkinChecker() {
	return (
		<div className="skin-checker">
			<div className="skin-checker__container">
				<div className="skin-checker__container-titlebox">
					<h1 className="skin-checker__container-title">
						SKIN CHECKER
					</h1>
					<form className="skin-checker__container-form">
						<Link to={`/itemFAQ`}>
							<button className="skin-checker__container-button">
								How-to-use / F-A-Q
							</button>
						</Link>
					</form>
				</div>
				<div className="skin-checker__table-headers">
					<div>
						<p>Weapon</p>
						<select className="skin-checker__item-select">
							<option>AK-47</option>
							<option>AWP</option>
							<option>Desert Eagle</option>
						</select>
						<p>Skin</p>
						<select className="skin-checker__item-select">
							<option>Case-Hardened</option>
							<option>Asiimov</option>
						</select>
						<p>Float</p>
						<input className="skin-checker__item-float-input"></input>
						<p>Pattern</p>
						<input className="skin-checker__item-pattern-input"></input>
						<button>Check</button>
					</div>
				</div>
			</div>
		</div>
	);
}

export default SkinChecker;
