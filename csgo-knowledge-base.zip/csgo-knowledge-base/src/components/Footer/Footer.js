import "./Footer.scss";

const Footer = () => {
    return (
        <article className="footer">
            <p className="footer__text">
             © Counter-Strike Knowledge Base 2023
            </p>
        </article>
    )
}

export default Footer;