// urlcheck-controller.js

const knex = require("knex")(require("../knexfile"));

// Controller functions

// Get all URL checks
const checkUrls = async (req, res) => {
	const { urls } = req.body;

	try {
		// Fetch URLs from the database (excluding null values)
		const dbUrls = await knex
			.select("url")
			.from("urlcheck")
			.whereNotNull("url");

		// Check each input URL against database URLs
		const results = urls.map((inputUrl) => {
			if (!inputUrl) {
				return {
					url: inputUrl,
					status: "Invalid URL",
				};
			}

			const isMatch = dbUrls.some((dbUrl) => dbUrl.url === inputUrl);

			return {
				url: inputUrl,
				status: isMatch ? "Match" : "No Match",
			};
		});

		res.status(200).json(results);
	} catch (error) {
		console.error(error); // Log the error for debugging
		res.status(500).json({ message: "Internal Server Error" });
	}
};

// Get a specific URL check by ID
const getUrlCheckById = async (req, res) => {
	const id = req.params.id;
	try {
		const urlCheck = await knex
			.select()
			.from("urlcheck")
			.where({ id })
			.first();
		res.json(urlCheck);
	} catch (error) {
		res.status(500).json({ message: error.message });
	}
};

// Add a new URL check
const addUrlCheck = async (req, res) => {
	const { url, status, domain } = req.body;

	try {
		const newUrlCheckId = await knex("urlcheck").insert({
			url,
			status,
			domain,
		});
		const newUrlCheck = await knex
			.select()
			.from("urlcheck")
			.where({ id: newUrlCheckId[0] })
			.first();
		res.status(201).json(newUrlCheck);
	} catch (error) {
		res.status(400).json({ message: error.message });
	}
};

// Extract domain from URL (you may need a more robust implementation based on your requirements)
const extractDomain = (url) => {
	const match = url.match(/^https?:\/\/([^/?#]+)(?:[/?#]|$)/i);
	return match && match[1];
};

// Export controller functions
module.exports = {
	checkUrls,
	getUrlCheckById,
	addUrlCheck,
};
